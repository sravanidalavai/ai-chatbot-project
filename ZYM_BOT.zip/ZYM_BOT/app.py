import json

print("Gym Bot Started")

# ---- Load FAQ ----
faq_file = open("faq.txt", "r")
faq_text = faq_file.read().lower()
faq_file.close()

# ---- Load bussiness info JSON ----
file = open("bussiness_info.json", "r")
data = json.load(file)
file.close()

# ---- Ask user question ----
question = input("Ask a gym question: ").lower()

answered = False

# ---- Check FAQ first ----
if "personal training" in question and "personal training" in faq_text:
    print("Yes, we offer personal training.")
    answered = True

if "locker" in question and "locker" in faq_text:
    print("Yes, lockers are available.")
    answered = True


# ---- Check JSON info ----
if "hour" in question:
    print("We are open:", data["hours"])
    answered = True

if "price" in question or "cost" in question:
    print("Our pricing is:", data["pricing"])
    answered = True

if "phone" in question:
    print("Call us at:", data["phone"])
    answered = True

if "address" in question or "location" in question:
    print("We are located at:", data["address"])
    answered = True


# ---- If nothing matched ----
if answered == False:
    print("I want to help, but your question is unclear.")